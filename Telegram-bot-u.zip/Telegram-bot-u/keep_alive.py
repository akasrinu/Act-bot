from flask import Flask
import threading
import time

app = Flask(__name__)

@app.route('/')
def home():
    return "Telegram Bot is Running! 🤖"

@app.route('/status')
def status():
    return {
        "status": "active",
        "timestamp": time.time(),
        "message": "Bot is operational",
        "uptime": "Available via Flask server"
    }

@app.route('/health')
def health():
    """Health check endpoint for external monitoring"""
    return {
        "status": "healthy",
        "service": "telegram-bot",
        "timestamp": time.time()
    }

def run():
    app.run(host='0.0.0.0', port=5000, debug=False)

def keep_alive():
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()