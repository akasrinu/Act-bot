import re
import asyncio
import datetime
import random
import pytz
from telethon import TelegramClient, events
from keep_alive import keep_alive

# -----------------------------
# Telegram API credentials
# -----------------------------
api_id = 27768006
api_hash = "f959f7acb183b6a002562e8137d6fe26"
phone = "+919999265383"

# -----------------------------
# Channel configurations
# -----------------------------
all_source_channels = [
    -1002545468726,
    -1001899590869,
    -1001473927376,  # to exclude
    -1001210518959,  # to exclude
    -1001600444335,  # new channel
    1001516168694,    # new channel
    1001816651237     # added new channel
]

EXCLUDE_CHANNELS = [
    -1001473927376,
    -1001210518959
]

source_channels = [ch for ch in all_source_channels if ch not in EXCLUDE_CHANNELS]
target_channel = -1002889285630

# -----------------------------
# Notification settings
# -----------------------------
NOTIFICATION_USER_ID = "me"

# Bot status tracking
bot_status = {
    "last_heartbeat": None,
    "error_count": 0,
    "is_running": True,
    "last_message_time": None
}

# -----------------------------
# Initialize client
# -----------------------------
client = TelegramClient("session", api_id, api_hash)

# -----------------------------
# Timezone
# -----------------------------
IST = pytz.timezone('Asia/Kolkata')

# -----------------------------
# Regex patterns
# -----------------------------
EMOJI_PATTERN = re.compile("["
    "\U0001F600-\U0001F64F"
    "\U0001F300-\U0001F5FF"
    "\U0001F680-\U0001F6FF"
    "\U0001F1E0-\U0001F1FF"
    "\U00002500-\U00002BEF"
    "\U00002702-\U000027B0"
    "\U00002702-\U000027B0"
    "\U000024C2-\U0001F251"
    "]+", flags=re.UNICODE)

URL_PATTERN = re.compile(r'http[s]?://|www\.', re.IGNORECASE)

SKIP_WORDS = [
    "ss", "bhai", "aap", "best application", "enrich money",
    "important information", "fake alert", "pls read and follow",
    "all members", "new traders", "too much slow", "koi", "@swindexhelp",
    "good morning", "gm", "quote of the day"
]

# -----------------------------
# Utility functions
# -----------------------------
def remove_emojis(text: str) -> str:
    return EMOJI_PATTERN.sub(r'', text)

def should_skip(text: str) -> bool:
    return any(word in text.lower() for word in SKIP_WORDS)

def contains_link(text: str) -> bool:
    return bool(URL_PATTERN.search(text))

def log_with_timestamp(filename: str, message: str):
    """Safe logging function"""
    try:
        with open(filename, "a", encoding="utf-8") as f:
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")
    except Exception as e:
        print(f"⚠️ Logging error: {e}")

# -----------------------------
# Notification functions
# -----------------------------
async def send_notification(message: str):
    """Send notification to your personal Telegram"""
    try:
        await client.send_message(NOTIFICATION_USER_ID, f"🤖 Bot Alert: {message}")
        print(f"📱 Notification sent: {message}")
    except Exception as e:
        print(f"❌ Failed to send notification: {e}")

# -----------------------------
# Event handler
# -----------------------------
@client.on(events.NewMessage(chats=source_channels))
async def handler(event):
    try:
        # Update status
        bot_status["last_heartbeat"] = datetime.datetime.now()
        bot_status["last_message_time"] = datetime.datetime.now()

        if event.chat_id in EXCLUDE_CHANNELS:
            return  

        message_text = event.message.message
        if not message_text or event.message.media:
            preview = (message_text or "no text")[:50]
            print(f"📷 Skipped (media or empty): {preview}...")
            return

        now = datetime.datetime.now(IST).time()
        if not (datetime.time(8, 0) <= now <= datetime.time(23, 0)):
            preview = message_text[:50]
            print(f"🕒 Skipped (outside working hours): {preview}...")
            return

        clean_text = remove_emojis(message_text).strip()

        if contains_link(clean_text):
            print(f"🔗 Skipped (link detected): {clean_text[:50]}...")
            return
        if should_skip(clean_text):
            print(f"🚫 Skipped (keyword match): {clean_text[:50]}...")
            return

        delay = random.randint(1, 3)
        if random.randint(1, 10) == 5:
            delay = random.randint(1, 6)
        print(f"⏳ Waiting {delay}s before sending...")
        await asyncio.sleep(delay)

        try:
            await client.send_message(target_channel, clean_text)
            print(f"✅ Forwarded: {clean_text[:100]}")
            log_with_timestamp("forwarded.log", f"Success: {clean_text[:100]}")

        except Exception as e:
            print(f"❌ Failed to send: {e}")
            log_with_timestamp("error.log", f"Send Error: {str(e)}")

    except Exception as e:
        error_msg = str(e)

        # Log handler errors but don't let them crash the bot
        log_with_timestamp("error.log", f"Handler Error: {error_msg}")

        # Only print critical errors, ignore sync issues
        if "PersistentTimestampOutdatedError" not in error_msg and "GetChannelDifferenceRequest" not in error_msg:
            print(f"❌ Handler error: {e}")
            bot_status["error_count"] += 1

# -----------------------------
# Keep alive function
# -----------------------------
async def keep_bot_alive():
    """Simple keep-alive without external health checks"""
    consecutive_failures = 0

    while True:
        try:
            now = datetime.datetime.now(IST).time()
            if datetime.time(8, 0) <= now <= datetime.time(23, 0):
                # Simple ping to keep connection alive
                me = await client.get_me()
                bot_status["last_heartbeat"] = datetime.datetime.now()
                bot_status["is_running"] = True
                consecutive_failures = 0
                print(f"💓 Keep-alive ping (User: {me.first_name})")
                await asyncio.sleep(300)  # 5 minutes
            else:
                # Sleep during off hours
                print("😴 Outside working hours, sleeping...")
                await asyncio.sleep(1800)  # 30 minutes during off hours

        except Exception as e:
            consecutive_failures += 1
            print(f"⚠️ Keep-alive failed ({consecutive_failures}): {e}")

            if consecutive_failures >= 5:
                print("❌ Too many keep-alive failures, but continuing...")
                consecutive_failures = 0  # Reset and continue

            await asyncio.sleep(60)  # Wait 1 minute before retry

# -----------------------------
# Main function
# -----------------------------
async def main():
    while True:  # Infinite retry loop
        try:
            print("🔄 Starting Telegram bot...")
            bot_status["is_running"] = True
            bot_status["error_count"] = 0

            await client.start(phone=phone)
            print("✅ Logged in. Listening for messages...")

            # Send startup notification only once per session
            try:
                await send_notification("Bot started successfully! ✅")
            except:
                pass  # Don't fail if notification fails

            # Create tasks for bot operation
            tasks = [
                asyncio.create_task(client.run_until_disconnected()),
                asyncio.create_task(keep_bot_alive())
            ]

            # Wait for any task to complete (shouldn't happen normally)
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)

            # Cancel remaining tasks
            for task in pending:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        except KeyboardInterrupt:
            print("🛑 Bot stopped by user")
            bot_status["is_running"] = False
            try:
                await send_notification("Bot stopped by user ⏹️")
            except:
                pass
            break

        except Exception as e:
            error_msg = str(e)
            print(f"❌ Bot error: {error_msg}")
            log_with_timestamp("error.log", f"Main Error: {error_msg}")

            # Clean disconnect
            try:
                if client.is_connected():
                    await client.disconnect()
                    print("🔌 Client disconnected")
            except:
                pass

            # Wait before restarting
            print("🔄 Restarting in 30 seconds...")
            await asyncio.sleep(30)

    print("🛑 Bot service stopped")

if __name__ == "__main__":
    print("🚀 Starting Telegram Bot Service...")
    keep_alive()
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("🛑 Service stopped by user")